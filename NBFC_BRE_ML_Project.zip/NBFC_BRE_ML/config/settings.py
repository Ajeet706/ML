"""Central configuration for the NBFC BRE ML prototype."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_FILE = ROOT / "data" / "raw" / "Synthetic_SingleSheetBRE_50K.xlsx"
APP_SHEET = "SingleSheetBRE"
RCPT_SHEET = "Receipt Payment"

MODEL_VERSION = "BRE_ML_v0.1_prototype"

# Target: user-defined business definition (not documented in the file itself).
TARGET_SOURCE_COLUMN = "Process_from_BRE"
TARGET_MAP = {"Y": 1, "N": 0}          # Y = PASS, N = NOT PASS
TARGET_NAME = "BRE_TARGET"

# Time-aware split on APPLICATION_DATE (month periods)
TRAIN_MONTHS = ["2026-04", "2026-05", "2026-06"]
VALID_MONTHS = ["2026-07", "2026-08"]
TEST_MONTHS = ["2026-09"]

# Prediction policy
PASS_THRESHOLD = 0.50                   # configurable decision threshold
MANUAL_REVIEW_BAND = 0.10               # |p - threshold| < band -> manual review
RANDOM_STATE = 42

# Features available at BRE assessment time (application-stage information only)
NUMERIC_FEATURES = ["Loan Amount Requested", "Requested Tenure", "Net LTV", "Age"]
CATEGORICAL_FEATURES = ["Branch Code", "Channel", "Product Code", "Scheme Code", "Loan Purpose"]
# Gender is excluded by default pending an approved fairness/policy decision.
INCLUDE_GENDER = False

ID_COLUMNS = ["APPLICATION_NUMBER", "CUSTOMERID"]
