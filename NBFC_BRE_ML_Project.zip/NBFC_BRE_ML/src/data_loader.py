"""Load the raw workbook sheets without altering original column names."""
import pandas as pd
from config import settings as S


def load_raw():
    xl = pd.ExcelFile(S.RAW_FILE)
    app = xl.parse(S.APP_SHEET)
    rcpt = xl.parse(S.RCPT_SHEET)
    return app, rcpt
