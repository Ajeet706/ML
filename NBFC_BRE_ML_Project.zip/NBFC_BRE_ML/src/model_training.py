"""Time-aware split and model definitions."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from config import settings as S


def time_split(app: pd.DataFrame):
    m = app["APPLICATION_DATE"].dt.to_period("M").astype(str)
    return (m.isin(S.TRAIN_MONTHS).values, m.isin(S.VALID_MONTHS).values, m.isin(S.TEST_MONTHS).values)


def preprocessor(num_cols, cat_cols):
    num = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())])
    cat = Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                    ("oh", OneHotEncoder(handle_unknown="ignore", min_frequency=20, sparse_output=False))])
    return ColumnTransformer([("num", num, num_cols), ("cat", cat, cat_cols)])


def build_models(num_cols, cat_cols):
    rs = S.RANDOM_STATE
    specs = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=rs),
        "Decision Tree": DecisionTreeClassifier(max_depth=4, min_samples_leaf=100, class_weight="balanced", random_state=rs),
        "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=6, min_samples_leaf=50,
                                                class_weight="balanced", n_jobs=-1, random_state=rs),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=150, max_depth=3, learning_rate=0.05,
                                                        subsample=0.8, random_state=rs),
    }
    return {n: Pipeline([("pre", preprocessor(num_cols, cat_cols)), ("clf", m)]) for n, m in specs.items()}


def fit_all(models, X, y, train_mask):
    for p in models.values():
        p.fit(X[train_mask], y[train_mask])
    return models
