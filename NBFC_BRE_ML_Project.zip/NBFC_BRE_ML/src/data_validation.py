"""Target validation and basic data-quality checks."""
import pandas as pd
from config import settings as S


def build_target(app: pd.DataFrame) -> pd.Series:
    """BRE_TARGET from Process_from_BRE: Y -> 1 (PASS), N -> 0 (NOT PASS).

    The Y/N = PASS/NOT PASS meaning is a user-provided business definition.
    It is not documented in the workbook itself.
    """
    raw = app[S.TARGET_SOURCE_COLUMN]
    unexpected = set(raw.dropna().unique()) - set(S.TARGET_MAP)
    if unexpected or raw.isna().any():
        raise ValueError(f"Unexpected / missing target values: {unexpected}, nulls={raw.isna().sum()}")
    return raw.map(S.TARGET_MAP).rename(S.TARGET_NAME)


def target_checks(app: pd.DataFrame) -> pd.DataFrame:
    y = build_target(app)
    rows = [
        ("Target source column", S.TARGET_SOURCE_COLUMN),
        ("Mapping", "Y = PASS (1), N = NOT PASS (0) - user-defined"),
        ("PASS count", int((y == 1).sum())),
        ("NOT PASS count", int((y == 0).sum())),
        ("PASS share", round(float(y.mean()), 4)),
        ("TAG identical to target (leakage)", bool((app["TAG"].eq("POST_BRE").astype(int) == y).all())),
    ]
    return pd.DataFrame(rows, columns=["Item", "Value"])


def missing_summary(df: pd.DataFrame) -> pd.DataFrame:
    m = df.isna().sum()
    return pd.DataFrame({"Column": m.index, "Missing": m.values,
                         "MissingPct": (m.values / len(df) * 100).round(2)})
