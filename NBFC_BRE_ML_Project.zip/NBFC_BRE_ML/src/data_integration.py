"""Application-level dataset: one row per APPLICATION_NUMBER.

Receipt Payment is one-to-many on APPLICATION_NUMBER and contains only repayment
data, which exists after disbursal. It is aggregated for reconciliation and process
analysis but is NOT used as a model input (post-decision information).
"""
import pandas as pd


def aggregate_receipts(rcpt: pd.DataFrame) -> pd.DataFrame:
    g = rcpt.groupby("APPLICATION_NUMBER")
    return g.agg(receipt_count=("RECEIPT_ID", "size"),
                 receipt_amount_sum=("AMOUNT", "sum"),
                 bounced_count=("RECEIPT_STATUS", lambda s: (s == "BOUNCED").sum()),
                 max_dpd_at_receipt=("DPD_AT_RECEIPT", "max")).reset_index()


def build_application_dataset(app: pd.DataFrame, rcpt: pd.DataFrame) -> pd.DataFrame:
    agg = aggregate_receipts(rcpt)
    out = app.merge(agg, on="APPLICATION_NUMBER", how="left", validate="one_to_one")
    assert len(out) == len(app) and out.APPLICATION_NUMBER.is_unique, "grain broken by join"
    return out
