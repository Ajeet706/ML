"""Application-level predictions with per-application explanations."""
import numpy as np
import pandas as pd
import shap
from config import settings as S


def _feature_names(pipe):
    return list(pipe.named_steps["pre"].get_feature_names_out())


def predict_frame(pipe, X, app, y, split_labels, model_version=S.MODEL_VERSION):
    p = pipe.predict_proba(X)[:, 1]
    pred = np.where(p >= S.PASS_THRESHOLD, "PASS", "NOT PASS")
    conf = np.maximum(p, 1 - p)
    review = np.abs(p - S.PASS_THRESHOLD) < S.MANUAL_REVIEW_BAND
    actual = np.where(y == 1, "PASS", "NOT PASS")
    out = pd.DataFrame({
        "APPLICATION_NUMBER": app["APPLICATION_NUMBER"].values,
        "CUSTOMER_ID": app["CUSTOMERID"].values,
        "APPLICATION_MONTH": app["APPLICATION_DATE"].dt.to_period("M").astype(str).values,
        "DATA_SPLIT": split_labels,
        "BRE_ACTUAL_STATUS": actual,
        "BRE_PREDICTED_STATUS": pred,
        "PASS_PROBABILITY": p.round(4),
        "NOT_PASS_PROBABILITY": (1 - p).round(4),
        "PREDICTION_CONFIDENCE": conf.round(4),
        "PREDICTION_RESULT": np.where(actual == pred, "Correct", "Incorrect"),
        "MANUAL_REVIEW_FLAG": np.where(review, "Review", "-"),
        "MODEL_VERSION": model_version,
    })
    return out


def top_factors(pipe, X, k=3, background=300):
    """Per-application top-k SHAP contributions on the model's own transformed features.

    Contributions describe association with the model's output, not causation.
    """
    pre, clf = pipe.named_steps["pre"], pipe.named_steps["clf"]
    Z = pre.transform(X)
    names = _feature_names(pipe)
    if hasattr(clf, "feature_importances_"):
        sv = shap.TreeExplainer(clf).shap_values(Z)
        sv = sv[1] if isinstance(sv, list) else (sv[..., 1] if sv.ndim == 3 else sv)
    else:
        bg = Z[np.random.default_rng(S.RANDOM_STATE).choice(len(Z), min(background, len(Z)), replace=False)]
        sv = shap.LinearExplainer(clf, bg).shap_values(Z)
    texts = []
    for row in sv:
        idx = np.argsort(-np.abs(row))[:k]
        texts.append("; ".join(f"{names[i].split('__',1)[-1]} ({'+' if row[i]>0 else '-'}{abs(row[i]):.3f} toward {'PASS' if row[i]>0 else 'NOT PASS'})" for i in idx))
    global_imp = pd.DataFrame({"Feature": names, "MeanAbsSHAP": np.abs(sv).mean(axis=0)}).sort_values("MeanAbsSHAP", ascending=False)
    return texts, global_imp
