"""Univariate association screen of every application-sheet column against BRE_TARGET.

Used to answer: is there ANY detectable relationship between the target and the data?
Numeric/date columns: Mann-Whitney U. Categorical: chi-square. Missingness of a column
is also tested. Bonferroni correction over all tests.
"""
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import cross_val_score
from config import settings as S

TAT_STAGES = ["LEAD_DETAILS", "DDE", "FIV", "FIC", "FII", "RCU_INITIATION",
              "COLLATERAL_INVESTIGATION_INITIATION", "RECOMMENDATION",
              "COLLATERAL_INVESTIGATION_VERIFICATION", "COLLATERAL_INVESTIGATION_COMPLETION",
              "CREDIT_APPROVAL", "CANCELLATION", "POST_APPROVAL", "DISBURSAL", "KFS_STAGE",
              "DISBURSAL_AUTHOR", "REJECTION", "SEND_TO_OPTS"]


def association_screen(app: pd.DataFrame, y: np.ndarray, skip=("Process_from_BRE", "TAG")) -> pd.DataFrame:
    rows = []
    for c in app.columns:
        if c in skip:
            continue
        s = app[c]
        if s.nunique(dropna=True) <= 1 or s.nunique() == len(s):  # constant or identifier
            kind, p, stat = ("identifier/constant", np.nan, np.nan)
        else:
            if pd.api.types.is_datetime64_any_dtype(s):
                v = s.map(pd.Timestamp.toordinal) if s.notna().all() else s.map(lambda d: d.toordinal() if pd.notna(d) else np.nan)
                s_num = v
            else:
                s_num = s
            if pd.api.types.is_numeric_dtype(s_num) and s_num.nunique() > 12:
                a, b = s_num[y == 1].dropna(), s_num[y == 0].dropna()
                p = stats.mannwhitneyu(a, b).pvalue; kind = "numeric (Mann-Whitney)"
                stat = a.median() - b.median()
            else:
                ct = pd.crosstab(s.fillna("MISSING"), y)
                chi = stats.chi2_contingency(ct)
                p = chi[1]; kind = "categorical (chi-square)"
                n = ct.values.sum(); stat = np.sqrt(chi[0] / (n * (min(ct.shape) - 1)))  # Cramer's V
        rows.append({"Column": c, "Test": kind, "Effect": stat, "p_value": p})
    out = pd.DataFrame(rows)
    m = out.p_value.notna().sum()
    out["p_bonferroni"] = (out.p_value * m).clip(upper=1)
    out["Significant (Bonferroni, 5%)"] = out.p_bonferroni < 0.05
    return out.sort_values("p_value").reset_index(drop=True)


def sequence_checks(app: pd.DataFrame, y: np.ndarray) -> dict:
    """Does order (application number / date) carry information about the target?"""
    order = np.argsort(app.APPLICATION_NUMBER.values)
    ys = y[order]
    runs = 1 + int((ys[1:] != ys[:-1]).sum())
    n1, n0 = ys.sum(), len(ys) - ys.sum()
    mu = 2 * n1 * n0 / len(ys) + 1
    var = (mu - 1) * (mu - 2) / (len(ys) - 1)
    z = (runs - mu) / np.sqrt(var)
    lag1 = float(np.corrcoef(ys[1:], ys[:-1])[0, 1])
    num = app.APPLICATION_NUMBER.str.extract(r"(\d+)$")[0].astype(int).values
    even_match = float(((num % 2 == 0).astype(int) == y).mean())
    return {"Wald-Wolfowitz runs z (sorted by application no.)": round(float(z), 3),
            "Lag-1 autocorrelation of target": round(lag1, 4),
            "Share of rows where target == (application number is even)": round(even_match, 4),
            "Application numbers contiguous 1..N": bool((np.sort(num) == np.arange(num.min(), num.max() + 1)).all())}


def tat_leakage_demo(app: pd.DataFrame, y: np.ndarray) -> float:
    """CV AUC predicting the target from TAT stage columns - shows TAT encodes the route."""
    X = app[TAT_STAGES]
    return float(cross_val_score(GradientBoostingClassifier(n_estimators=100, max_depth=3, random_state=S.RANDOM_STATE),
                                 X, y, cv=5, scoring="roc_auc").mean())
