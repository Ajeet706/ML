"""Feature engineering restricted to information available at BRE assessment time."""
import pandas as pd
from config import settings as S

# Excluded columns and why. Every column of the application sheet is accounted for
# either here, in the feature list, or as an identifier.
EXCLUSION_REASONS = {
    "Process_from_BRE": "Target source",
    "TAG": "Identical to target (Pre_BRE/POST_BRE is the same flag)",
    "STATUS": "Post-decision workflow status; meaning undocumented",
    "Conver_in_loan_FLAG": "Downstream conversion outcome",
    "LOANID": "Created after approval",
    "DISBURSAL_DATE": "Post-decision",
    "Disbursal Status": "Post-decision outcome",
    "Disbursed Amount": "Post-decision outcome",
    "Sanction Loan Amount": "Sanction occurs after BRE; also = f(requested amount)",
    "Sanctioned ROI": "Set at sanction, after BRE",
    "APPROVAL_DATE": "Post-decision",
    "LOAN_BOARDING_DATE": "Post-decision",
    "MATURITY_DATE": "Post-decision",
    "LOAN_AMOUNT_PAID": "Repayment performance",
    "OVERDUE_PRINCIPAL_AMOUNT": "Future performance",
    "OVERDUE_INTEREST_AMOUNT": "Future performance",
    "OVERDUE_INSTALMENT_AMOUNT": "Future performance",
    "NUMBER_OF_OVERDUE_INSTL": "Future performance",
    "NUMBER_OF_INSTRUMENT_RETURN": "Future performance",
    "LAST_PAYMENT_DATE": "Future performance",
    "LAST_RECEIPT_DATE": "Future performance",
    "NEXT_INSTALLMENT_DUE_DATE": "Future performance",
    "NEXT_INSTALLMENT_DUE_AMOUNT": "Future performance",
    "DAYS_PAST_DUE": "Future DPD",
    "COLLATERAL_NUMBER": "Populated only for disbursed loans (missingness reveals outcome)",
    "COLLATERAL_TYPE": "Populated only for disbursed loans",
    "ASSET_TYPE": "Populated only for disbursed loans",
    "MANUFACTURER": "Populated only for disbursed loans",
    "ASSET_MODEL_CODE": "Populated only for disbursed loans",
    "VARIANT": "Populated only for disbursed loans",
    "ASSET_USAGE": "Populated only for disbursed loans",
    "BOUGHT_FROM": "Populated only for disbursed loans",
    "FAIRMKT_BASE_VALUE": "Populated only for disbursed loans",
    "PROPERTY_CITY": "Collateral detail, disbursed loans only",
    "PROPERTY_STATE": "Collateral detail, disbursed loans only",
    "PROPERTY_TYPE": "Collateral detail, disbursed loans only",
    "Loan Account No": "Identifier; created after disbursal",
    "LOAN_ACCOUNT_NO": "Identifier; created after disbursal",
    "Neo CIF ID": "Identifier (duplicate of CUSTOMERID)",
    "CUSTOMERID": "Identifier",
    "APPLICATION_NUMBER": "Identifier. Target equals 'application number is even' on 100% of rows, so it would leak the label (spurious AUC 1.0)",
    "Customer Name": "Identifier / PII",
    "CUSTOMER_NAME": "Identifier / PII (duplicate)",
    "Branch Name": "Duplicate of Branch Code",
    "Product Type Code": "Duplicate / conflicting product descriptor",
    "Product Type": "Duplicate / conflicting product descriptor",
    "Product": "Duplicate of Product Code",
    "Scheme": "Duplicate of Scheme Code",
    "PRODUCT_CODE": "Duplicate of Product Code",
    "PRODUCT_TYPE": "Duplicate / conflicting product descriptor",
    "PRODUCT_DESCRIPTION": "Conflicts with Product on ~half the rows",
    "SCHEME_DESCRIPTION": "Duplicate of Scheme",
    "PRODUCT_NAME": "Duplicate / conflicting product descriptor",
    "Gender": "Excluded pending fairness/policy approval (config.INCLUDE_GENDER)",
    "APPLICATION_DATE": "Used only for time split and application month",
}
_STAGE_REASON = "Workflow TAT stage; recorded during/after processing, unit undocumented"
for c in ["LEAD_DETAILS", "DDE", "FIV", "FIC", "FII", "RCU_INITIATION",
          "COLLATERAL_INVESTIGATION_INITIATION", "RECOMMENDATION",
          "COLLATERAL_INVESTIGATION_VERIFICATION", "COLLATERAL_INVESTIGATION_COMPLETION",
          "CREDIT_APPROVAL", "CANCELLATION", "POST_APPROVAL", "DISBURSAL", "KFS_STAGE",
          "DISBURSAL_AUTHOR", "REJECTION", "SEND_TO_OPTS"]:
    EXCLUSION_REASONS[c] = _STAGE_REASON


def feature_lists():
    num = list(S.NUMERIC_FEATURES)
    cat = list(S.CATEGORICAL_FEATURES)
    if S.INCLUDE_GENDER:
        cat.append("Gender")
    return num, cat


def engineer(app: pd.DataFrame) -> pd.DataFrame:
    """Return a feature frame (same index as app) using application-stage fields only."""
    num, cat = feature_lists()
    X = app[num + cat].copy()
    X["application_month"] = app["APPLICATION_DATE"].dt.month
    X["amount_per_tenure_month"] = app["Loan Amount Requested"] / app["Requested Tenure"]
    X["age_band"] = pd.cut(app["Age"], [0, 30, 40, 50, 60, 120], labels=["<=30", "31-40", "41-50", "51-60", "60+"]).astype(str)
    return X


def model_columns():
    num, cat = feature_lists()
    return (num + ["application_month", "amount_per_tenure_month"], cat + ["age_band"])


def leakage_report(app: pd.DataFrame) -> pd.DataFrame:
    num, cat = feature_lists()
    used = set(num + cat)
    rows = []
    for c in app.columns:
        if c in used:
            rows.append((c, "USED AS FEATURE", "Available at application stage"))
        else:
            rows.append((c, "EXCLUDED", EXCLUSION_REASONS.get(c, "UNREVIEWED - add reason")))
    return pd.DataFrame(rows, columns=["Column", "Decision", "Reason"])
