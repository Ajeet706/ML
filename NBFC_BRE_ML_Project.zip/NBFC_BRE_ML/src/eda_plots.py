"""EDA figures: PASS (Y) vs NOT PASS (N) on Process_from_BRE."""
import textwrap
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config import settings as S
from src import signal_screen as ss

C_PASS, C_NOT = "#1f77b4", "#d95f02"
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titlesize": 11, "axes.labelsize": 9, "figure.dpi": 130})


def _rate_ci(df, col, y):
    g = pd.DataFrame({"k": df[col].astype(str), "y": y}).groupby("k").y.agg(["mean", "size"])
    g["ci"] = 1.96 * np.sqrt(g["mean"] * (1 - g["mean"]) / g["size"])
    return g.sort_values("mean")


def make_all(app: pd.DataFrame, y: np.ndarray, outdir):
    outdir.mkdir(parents=True, exist_ok=True)
    paths = []

    # 1 class balance by month
    m = app.APPLICATION_DATE.dt.to_period("M").astype(str)
    ct = pd.crosstab(m, y)
    fig, ax = plt.subplots(figsize=(6, 3.4))
    ct.plot(kind="bar", stacked=False, ax=ax, color=[C_NOT, C_PASS], width=0.75)
    ax.legend(["NOT PASS (N)", "PASS (Y)"], frameon=False); ax.set_xlabel(""); ax.set_ylabel("Applications")
    ax.set_title("PASS vs NOT PASS by application month"); plt.xticks(rotation=0)
    p = outdir / "01_target_by_month.png"; fig.tight_layout(); fig.savefig(p); plt.close(fig); paths.append(p)

    # 2 PASS rate by segment with 95% CI
    cols = ["Product", "Channel", "Loan Purpose", "Branch Name"]
    fig, axes = plt.subplots(2, 2, figsize=(10, 6.4))
    for ax, c in zip(axes.ravel(), cols):
        g = _rate_ci(app, c, y)
        ax.errorbar(g["mean"], range(len(g)), xerr=g["ci"], fmt="o", color=C_PASS, capsize=2)
        ax.axvline(y.mean(), color="grey", ls="--", lw=0.8)
        ax.set_yticks(range(len(g))); ax.set_yticklabels([textwrap.fill(s, 32) for s in g.index], fontsize=7)
        ax.set_xlim(0.40, 0.60); ax.set_title(f"PASS rate by {c}"); ax.set_xlabel("PASS share (95% CI)")
    fig.tight_layout(); p = outdir / "02_pass_rate_by_segment.png"; fig.savefig(p); plt.close(fig); paths.append(p)

    # 3 numeric distributions
    nums = ["Loan Amount Requested", "Net LTV", "Age", "Requested Tenure"]
    fig, axes = plt.subplots(2, 2, figsize=(10, 6))
    for ax, c in zip(axes.ravel(), nums):
        bins = np.histogram_bin_edges(app[c], bins=30)
        ax.hist(app.loc[y == 1, c], bins=bins, alpha=0.55, color=C_PASS, label="PASS (Y)")
        ax.hist(app.loc[y == 0, c], bins=bins, alpha=0.55, color=C_NOT, label="NOT PASS (N)")
        ax.set_title(c); ax.legend(frameon=False, fontsize=7)
    fig.suptitle("Distributions are near-identical for PASS and NOT PASS", fontsize=11)
    fig.tight_layout(); p = outdir / "03_numeric_distributions.png"; fig.savefig(p); plt.close(fig); paths.append(p)

    # 4 missing pattern
    nul = app.columns[app.isna().any()]
    miss = pd.DataFrame({"Disbursed": app.loc[app["Disbursal Status"] == "Fully Disbursed", nul].isna().mean(),
                         "Not disbursed": app.loc[app["Disbursal Status"] == "Not Disbursed", nul].isna().mean()})
    fig, ax = plt.subplots(figsize=(7, 5))
    miss.plot(kind="barh", ax=ax, color=[C_PASS, C_NOT]); ax.set_xlabel("Share missing")
    ax.set_title("Missing values are structural: they track disbursal, not the target"); ax.tick_params(axis="y", labelsize=7)
    fig.tight_layout(); p = outdir / "04_missing_pattern.png"; fig.savefig(p); plt.close(fig); paths.append(p)

    # 5 TAT ratio POST_BRE (Y) / Pre_BRE (N)
    ratio = pd.Series({c: app.loc[y == 1, c].mean() / app.loc[y == 0, c].mean() for c in ss.TAT_STAGES}).sort_values()
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.barh(range(len(ratio)), ratio.values, color=C_PASS)
    ax.set_yticks(range(len(ratio))); ax.set_yticklabels(ratio.index, fontsize=7); ax.axvline(1, color="grey", ls="--", lw=0.8)
    ax.set_xlim(0, 1.1); ax.set_xlabel("Mean stage time, Y / N")
    ax.set_title("All 18 stage times are ~0.75x for Y vs N\n(including early stages such as LEAD_DETAILS, DDE)", fontsize=10)
    fig.tight_layout(); p = outdir / "05_tat_ratio.png"; fig.savefig(p); plt.close(fig); paths.append(p)

    # 6 order pattern
    order = np.argsort(app.APPLICATION_NUMBER.values)
    fig, ax = plt.subplots(figsize=(8, 2.4))
    ax.step(range(1, 41), y[order][:40], where="mid", color=C_PASS)
    ax.set_yticks([0, 1]); ax.set_yticklabels(["N", "Y"]); ax.set_xlabel("Application number (first 40)")
    ax.set_title("Process_from_BRE alternates N, Y, N, Y ... by application number")
    fig.tight_layout(); p = outdir / "06_target_vs_application_number.png"; fig.savefig(p); plt.close(fig); paths.append(p)
    return paths
