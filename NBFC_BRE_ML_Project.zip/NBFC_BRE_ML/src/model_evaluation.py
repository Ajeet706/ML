"""Metrics, bootstrap confidence intervals and error analysis."""
import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, average_precision_score, confusion_matrix,
                             f1_score, precision_score, recall_score, roc_auc_score)
from config import settings as S


def metrics(y, proba, threshold=None):
    t = S.PASS_THRESHOLD if threshold is None else threshold
    pred = (proba >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "Accuracy": accuracy_score(y, pred),
        "Precision (PASS)": precision_score(y, pred, zero_division=0),
        "Recall (PASS)": recall_score(y, pred, zero_division=0),
        "Recall (NOT PASS)": tn / (tn + fp) if (tn + fp) else np.nan,
        "F1 (PASS)": f1_score(y, pred, zero_division=0),
        "ROC-AUC": roc_auc_score(y, proba),
        "PR-AUC": average_precision_score(y, proba),
        "TN (correct NOT PASS)": tn, "FP (false PASS)": fp,
        "FN (false NOT PASS)": fn, "TP (correct PASS)": tp,
        "False PASS rate": fp / (fp + tn) if (fp + tn) else np.nan,
        "False NOT PASS rate": fn / (fn + tp) if (fn + tp) else np.nan,
    }


def bootstrap_auc(y, proba, n=500, seed=S.RANDOM_STATE):
    rng = np.random.default_rng(seed)
    y = np.asarray(y); proba = np.asarray(proba)
    aucs = []
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if len(np.unique(y[i])) == 2:
            aucs.append(roc_auc_score(y[i], proba[i]))
    return float(np.percentile(aucs, 2.5)), float(np.percentile(aucs, 97.5))


def permutation_pvalue(y, proba, n=1000, seed=S.RANDOM_STATE):
    """Share of label shuffles whose AUC >= observed AUC (null: no signal)."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y); obs = roc_auc_score(y, proba)
    null = [roc_auc_score(rng.permutation(y), proba) for _ in range(n)]
    return float((np.sum(np.array(null) >= obs) + 1) / (n + 1))
