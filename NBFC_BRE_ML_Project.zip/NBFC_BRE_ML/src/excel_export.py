"""Write NBFC_BRE_ML_Prediction_Output.xlsx."""
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


def _style(path):
    wb = load_workbook(path)
    fill = PatternFill("solid", fgColor="1F3864")
    for ws in wb:
        for row in ws.iter_rows():
            for c in row:
                c.font = Font(name="Arial", size=10)
                c.alignment = Alignment(vertical="top", wrap_text=ws.title != "1_Application_Predictions")
        for c in ws[1]:
            c.font = Font(name="Arial", size=10, bold=True, color="FFFFFF"); c.fill = fill
        for i, col in enumerate(ws.columns, 1):
            w = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200])
            ws.column_dimensions[get_column_letter(i)].width = min(max(12, w + 2), 80)
        ws.freeze_panes = "A2"
    wb.save(path)


def export(path, sheets: dict):
    with pd.ExcelWriter(path, engine="openpyxl") as w:
        for name, df in sheets.items():
            df.to_excel(w, sheet_name=name, index=False)
    _style(path)
