# NBFC BRE ML prototype: management findings

Decision-support prototype only. It does not approve or reject loans, and its predictions are not official BRE decisions.

## Bottom line
The model cannot predict `Process_from_BRE` (Y = PASS, N = NOT PASS, as defined by the project owner). On the September out-of-time test, accuracy is 50.8% and ROC-AUC 0.505 (95% CI 0.487 to 0.524), which cannot be told apart from guessing (permutation p = 0.32). This was true for all four models. The reason is in the data, not the modelling: see Target validation.

## Target validation
| Check | Result |
|---|---|
| Class balance | 12,500 Y and 12,500 N (exactly 50/50, every month) |
| Columns tested against the target (73, Bonferroni 5%) | 18 significant, all workflow stage-time columns; none of the application, customer, product, branch, channel or collateral fields |
| Order check | Target equals "application number is even" on 100% of 25,000 rows; it alternates N, Y, N, Y by application number |
| Stage times | All 18 are about 0.75x for Y vs N, including early stages (LEAD_DETAILS, DDE). A model using only these scores ROC-AUC 0.986 |

A rule-engine eligibility outcome would be expected to depend on applicant and loan characteristics. This field depends on application sequence and, in turn, on processing time. The field is therefore very unlikely to be a PASS / NOT PASS eligibility result as populated in this file. Please confirm with the BRE or data owner how it was derived (for example, an extract that alternates applications between two processing routes). A model that used application-number parity or stage times would score near-perfectly and be worthless, so both are excluded.

## Answers to the eight management questions
1. **Which applications are likely to PASS?** None can be identified. Predicted PASS probabilities range only 0.44 to 0.55 across 3,929 test applications.
2. **Which are likely to NOT PASS?** Same answer.
3. **Main factors behind NOT PASS predictions?** None meaningful. SHAP values are about 0.003 and evenly spread (largest: branch BR004, requested amount, net LTV, age). These describe the model's noise, not causes.
4. **Characteristics associated with BRE failure?** None among application-stage fields. Branch (p = 0.06 uncorrected) and a few others show differences within sampling noise.
5. **How accurate is the model?** 50.8% accuracy, AUC 0.505 on out-of-time data, with rolling validation at about 0.50 for every model. Test confusion matrix (Random Forest): 1,031 correct PASS, 963 correct NOT PASS, 1,005 false PASS, 930 false NOT PASS.
6. **Which cases for manual review?** All 3,929 test cases fall in the review band (probability within 0.10 of the 0.50 threshold). The model gives no usable triage.
7. **Pre-BRE vs POST-BRE differences?** Y (POST_BRE) and N (Pre_BRE) populations match on amount, tenure, LTV, age, ROI, product, channel, purpose, gender, STATUS and disbursal rate. The only difference is stage times about 24% lower for POST_BRE across all 18 stages, which is the pattern flagged above.
8. **Additional data required?** The real BRE decision with run timestamp and policy version; rule-level results and reason codes; manual-override flag; and BRE-time inputs absent from the file (CIBIL, bureau DPD, enquiries, income, obligations, FOIR, collateral value at application). Definitions of STATUS A/C/X and the TAT unit are also needed.

## Other data-quality points
- 8,118 receipts belong to applications marked Not Disbursed; 8,927 receipts are dated after 30 Oct 2026; Product and PRODUCT_DESCRIPTION disagree on 12,493 rows; 1,939 applications have a loan ID but no disbursal. Details in `NBFC_BRE_Phase1_Report.xlsx`.
- Customers are unique per application, so customer-level leakage could not arise.

## Recommended next steps
1. Confirm how `Process_from_BRE` was produced.
2. Obtain the real BRE decision field and BRE-time inputs listed above.
3. Re-run `python3 run_pipeline.py` on that extract. Pipeline, features, evaluation and Excel export are ready.
4. Before any production use: credit-risk validation, policy approval, fairness review (Gender is excluded pending approval) and governance.

## Not done
XGBoost (not installed; scikit-learn Gradient Boosting used), branch-level fairness analysis, hyper-parameter tuning, and CIBIL/FOIR/income EDA (those fields are not in the file).
