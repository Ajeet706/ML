# NBFC BRE ML Prototype (decision support only)

Predicts BRE PASS / NOT PASS per application. It must not approve or reject real loans. Production use needs credit-risk validation, policy approval, fairness review and governance.

## Target
`BRE_TARGET` comes from `Process_from_BRE`: Y = PASS (1), N = NOT PASS (0). This mapping is a user-provided business definition, not documented in the workbook. `TAG` is identical to it and is excluded.

## Run
`python3 run_pipeline.py` (needs pandas, scikit-learn, shap, openpyxl, joblib, scipy). Settings (split months, threshold, manual-review band, Gender inclusion, features) are in `config/settings.py`.

## Structure
- `src/` modules: data loading, validation, integration, features/leakage, training, evaluation, prediction, Excel export
- `data/processed/` integrated application-level data and feature dataset
- `data/predictions/` application-level predictions (CSV)
- `models/bre_model.joblib` trained pipeline
- `outputs/NBFC_BRE_ML_Prediction_Output.xlsx` final workbook
- `reports/` leakage assessment, performance, feature importance, rolling validation
- `notebooks/` 01-07, generated and executed by `build_notebooks.py`
- `reports/Management_Findings.md` and `reports/figures/` EDA charts

## Method notes
- Split by application month: train Apr-Jun, validate Jul-Aug, test Sep. Rolling-origin check in sheet 6.
- Features are application-stage fields only. Every column is listed with an include/exclude reason in `reports/leakage_assessment.csv`.
- Receipt Payment is aggregated to application grain for reconciliation, not used as a feature (post-decision).
- Gender is excluded pending a fairness decision.
- Target validation found the target equals application-number parity; see `reports/Management_Findings.md`. Confirm how the field was populated before trusting any model.
