"""End-to-end run: validate target, build features, train, evaluate, explain, export."""
import sys, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
warnings.filterwarnings("ignore")

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import roc_auc_score

from config import settings as S
from src import (data_loader, data_validation, data_integration, feature_engineering as fe,
                 model_training as mt, model_evaluation as me, model_prediction as mp, excel_export)

# ---- Load, target, integration ------------------------------------------------
app, rcpt = data_loader.load_raw()
y = data_validation.build_target(app).values
full = data_integration.build_application_dataset(app, rcpt)
full.to_pickle(S.ROOT / "data" / "processed" / "application_level_integrated.pkl")

# ---- Features -----------------------------------------------------------------
X = fe.engineer(app)
num_cols, cat_cols = fe.model_columns()
X = X[num_cols + cat_cols]
X.assign(**{S.TARGET_NAME: y, "APPLICATION_NUMBER": app.APPLICATION_NUMBER.values}) \
    .to_csv(S.ROOT / "data" / "processed" / "feature_dataset.csv", index=False)

tr, va, te = mt.time_split(app)
print("split sizes", tr.sum(), va.sum(), te.sum(), "PASS share", y[tr].mean().round(3), y[va].mean().round(3), y[te].mean().round(3))

# ---- Train & compare ----------------------------------------------------------
models = mt.fit_all(mt.build_models(num_cols, cat_cols), X, y, tr)
rows = []
for name, pipe in models.items():
    for split, mask in [("Train", tr), ("Validation", va), ("Test", te)]:
        p = pipe.predict_proba(X[mask])[:, 1]
        rows.append({"Model": name, "Split": split, **me.metrics(y[mask], p)})
perf = pd.DataFrame(rows)

# Rolling-origin check: train on all earlier months, test on each later month
months = app["APPLICATION_DATE"].dt.to_period("M").astype(str).values
order = sorted(set(months))
roll = []
for k in range(2, len(order)):
    trm, tem = np.isin(months, order[:k]), months == order[k]
    for name in models:
        pipe = clone(mt.build_models(num_cols, cat_cols)[name]).fit(X[trm], y[trm])
        roll.append({"Model": name, "Test month": order[k], "Train months": k,
                     "ROC-AUC": roc_auc_score(y[tem], pipe.predict_proba(X[tem])[:, 1])})
roll = pd.DataFrame(roll)
roll_summary = roll.groupby("Model")["ROC-AUC"].agg(["mean", "min", "max"]).round(4).reset_index()

# ---- Selection: validation ROC-AUC; significance on test ---------------------
val = perf[perf.Split == "Validation"].set_index("Model")
best = val["ROC-AUC"].idxmax()
best_pipe = models[best]
pt = best_pipe.predict_proba(X[te])[:, 1]
ci = me.bootstrap_auc(y[te], pt)
pval = me.permutation_pvalue(y[te], pt)
test_auc = roc_auc_score(y[te], pt)
signal = (ci[0] > 0.5) and (pval < 0.05)
print(f"best={best} val_auc={val.loc[best,'ROC-AUC']:.4f} test_auc={test_auc:.4f} CI={ci} perm_p={pval:.3f} signal={signal}")
print(perf[perf.Split != "Train"][["Model", "Split", "Accuracy", "ROC-AUC", "PR-AUC", "F1 (PASS)"]].round(4).to_string())
print(roll_summary.to_string())

# ---- Explainability & predictions --------------------------------------------
texts, imp = mp.top_factors(best_pipe, X)
split_lbl = np.where(tr, "Train (Apr-Jun)", np.where(va, "Validation (Jul-Aug)", np.where(te, "Test (Sep)", "Unused")))
pred = mp.predict_frame(best_pipe, X, app, y, split_lbl)
pred["TOP_PREDICTION_FACTORS"] = texts
pred["NOTE"] = np.where(pred.DATA_SPLIT.str.startswith("Test"), "Out-of-time holdout", "In-sample / seen during model selection - not a performance estimate")
pred.to_csv(S.ROOT / "data" / "predictions" / "application_predictions.csv", index=False)
joblib.dump({"pipeline": best_pipe, "model_name": best, "version": S.MODEL_VERSION,
             "features": num_cols + cat_cols, "threshold": S.PASS_THRESHOLD},
            S.ROOT / "models" / "bre_model.joblib")

# ---- Excel --------------------------------------------------------------------
interp = {
    "Loan Amount Requested": "Size of the request relative to others",
    "Requested Tenure": "Requested repayment period in months",
    "Net LTV": "Loan-to-value at application",
    "Age": "Applicant age at application",
    "application_month": "Calendar month of application",
    "amount_per_tenure_month": "Requested amount divided by tenure (instalment-size proxy)",
    "Branch Code": "Originating branch", "Channel": "Sourcing channel", "Product Code": "Product",
    "Scheme Code": "Scheme", "Loan Purpose": "Purpose of the loan", "age_band": "Age band",
}
def interpret(f):
    base = f.split("__", 1)[-1]
    for k, v in interp.items():
        if base == k or base.startswith(k + "_"):
            return v + ". Association with model output only, not causation."
    return "Association with model output only, not causation."
imp = imp.rename(columns={"MeanAbsSHAP": "Importance (mean |SHAP|)"})
imp["Business Interpretation"] = imp.Feature.map(interpret)

tm = perf[(perf.Model == best) & (perf.Split == "Test")].iloc[0]
tdf = pred[pred.DATA_SPLIT.str.startswith("Test")]
validation = pd.DataFrame([
    ["Model", best], ["Test period", "Sep 2026 (out-of-time)"], ["Test applications", len(tdf)],
    ["Correct PASS", int(tm["TP (correct PASS)"])], ["Correct NOT PASS", int(tm["TN (correct NOT PASS)"])],
    ["False PASS (predicted PASS, actual NOT PASS)", int(tm["FP (false PASS)"])],
    ["False NOT PASS (predicted NOT PASS, actual PASS)", int(tm["FN (false NOT PASS)"])],
    ["Accuracy", round(tm["Accuracy"], 4)], ["Precision (PASS)", round(tm["Precision (PASS)"], 4)],
    ["Recall (PASS)", round(tm["Recall (PASS)"], 4)], ["F1 (PASS)", round(tm["F1 (PASS)"], 4)],
    ["ROC-AUC", round(test_auc, 4)], ["ROC-AUC 95% bootstrap CI", f"{ci[0]:.3f} - {ci[1]:.3f}"],
    ["Permutation p-value (null: no signal)", round(pval, 4)],
    ["Statistically distinguishable from chance?", "Yes" if signal else "No"],
    ["Manual-review flagged (test)", int((tdf.MANUAL_REVIEW_FLAG == "Review").sum())],
], columns=["Item", "Value"])

dq = pd.concat([
    data_validation.target_checks(app).assign(Section="Target definition"),
    pd.DataFrame([("Applications", len(app)), ("Receipt rows", len(rcpt)),
                  ("Applications after join", len(full)), ("Duplicate APPLICATION_NUMBER", int(full.APPLICATION_NUMBER.duplicated().sum())),
                  ("Applications with receipts", int(full.receipt_count.notna().sum()))],
                 columns=["Item", "Value"]).assign(Section="Join reconciliation"),
    data_validation.missing_summary(app).query("Missing > 0").rename(columns={"Column": "Item", "Missing": "Value"})[["Item", "Value"]].assign(Section="Missing fields (structural: no loan exists)"),
    fe.leakage_report(app).rename(columns={"Column": "Item"}).assign(Value=lambda d: d.Decision + ": " + d.Reason)[["Item", "Value"]].assign(Section="Feature inclusion / exclusion"),
], ignore_index=True)[["Section", "Item", "Value"]]

from src import signal_screen as ss
screen = ss.association_screen(app, y)
seq = ss.sequence_checks(app, y)
tat_auc = ss.tat_leakage_demo(app, y)
nontat_sig = [c for c in screen[screen["Significant (Bonferroni, 5%)"]].Column if c not in ss.TAT_STAGES]
tv = pd.DataFrame([
    ["Target definition", "Process_from_BRE: Y = PASS, N = NOT PASS (user-provided)"],
    ["Columns tested vs target (Bonferroni, 5%)", int(screen.p_value.notna().sum())],
    ["Significant columns", int(screen["Significant (Bonferroni, 5%)"].sum())],
    ["Significant columns that are NOT workflow TAT stages", ", ".join(nontat_sig) or "none"],
    *[[k, v] for k, v in seq.items()],
    ["CV ROC-AUC using only TAT stage columns", round(tat_auc, 4)],
    ["Interpretation", "Target is a deterministic function of application-number parity and TAT stages are scaled ~0.75x for Y; "
                       "this is not behaviour expected of a rule-engine eligibility outcome. Confirm how the field was populated."],
], columns=["Check", "Result"])
screen.to_csv(S.ROOT / "reports" / "association_screen.csv", index=False)
tv.to_csv(S.ROOT / "reports" / "target_validation.csv", index=False)

perf_out = perf.round(4)
excel_export.export(S.ROOT / "outputs" / "NBFC_BRE_ML_Prediction_Output.xlsx", {
    "1_Application_Predictions": pred,
    "2_Prediction_Validation": validation,
    "3_Feature_Importance": imp,
    "4_Data_Quality": dq,
    "5_Model_Performance": perf_out,
    "6_Rolling_Validation": roll.round(4),
    "7_Target_Validation": tv,
})
reports = S.ROOT / "reports"
perf_out.to_csv(reports / "model_performance.csv", index=False)
fe.leakage_report(app).to_csv(reports / "leakage_assessment.csv", index=False)
imp.to_csv(reports / "feature_importance.csv", index=False)
roll_summary.to_csv(reports / "rolling_validation_summary.csv", index=False)
print("done")
