"""Generate and execute notebooks 01-07 (run once; outputs are stored in the .ipynb files)."""
import sys
from pathlib import Path
import nbformat as nbf
from nbclient import NotebookClient

ROOT = Path(__file__).resolve().parent
SETUP = """import sys, warnings
from pathlib import Path
ROOT = Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()
sys.path.insert(0, str(ROOT)); warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
pd.set_option("display.width", 200); pd.set_option("display.max_columns", 40)
from config import settings as S
from src import data_loader, data_validation, data_integration, feature_engineering as fe, signal_screen as ss
app, rcpt = data_loader.load_raw()
y = data_validation.build_target(app).values"""

NB = {}
NB["01_data_understanding"] = [
 ("md", "# 01 Data understanding\nShape, columns, types, keys and date range of both sheets. Original column names are preserved."),
 ("code", SETUP),
 ("code", "print(app.shape, rcpt.shape)\nprint(app.dtypes.value_counts()); print(rcpt.dtypes.value_counts())"),
 ("code", "print('Application date range:', app.APPLICATION_DATE.min().date(), app.APPLICATION_DATE.max().date())\nprint(app.APPLICATION_DATE.dt.to_period('M').value_counts().sort_index())"),
 ("code", "keys = pd.DataFrame({'unique': [app.APPLICATION_NUMBER.nunique(), app.CUSTOMERID.nunique(), app.LOANID.nunique(), rcpt.RECEIPT_ID.nunique(), rcpt.APPLICATION_NUMBER.nunique()]},\n  index=['app.APPLICATION_NUMBER','app.CUSTOMERID','app.LOANID','rcpt.RECEIPT_ID','rcpt.APPLICATION_NUMBER'])\nkeys"),
 ("code", "for c in ['Channel','Product','Loan Purpose','Gender','STATUS','TAG','Process_from_BRE','Disbursal Status']:\n    print(app[c].value_counts(dropna=False).to_string(), '\\n')"),
 ("code", "app.describe().T.round(2).head(40)"),
]
NB["02_data_quality"] = [
 ("md", "# 02 Data quality\nMissing values, duplicates, anomalies. Missing loan/collateral fields are structural (no loan exists for non-disbursed applications)."),
 ("code", SETUP),
 ("code", "print('full-row duplicates:', app.duplicated().sum(), rcpt.duplicated().sum(), '| duplicate application numbers:', app.APPLICATION_NUMBER.duplicated().sum())"),
 ("code", "data_validation.missing_summary(app).query('Missing>0')"),
 ("code", "print('missing share by disbursal status (a few columns)')\nprint(app[['LOANID','COLLATERAL_TYPE','DAYS_PAST_DUE']].isna().groupby(app['Disbursal Status']).mean().round(3))"),
 ("code", "m = rcpt.merge(app[['APPLICATION_NUMBER','Disbursal Status']], on='APPLICATION_NUMBER')\nprint('receipts on Not Disbursed apps:', (m['Disbursal Status']=='Not Disbursed').sum())\nprint('receipts dated after 2026-10-30:', (rcpt.RECEIPT_DATE>'2026-10-30').sum())\nprint('Product vs PRODUCT_DESCRIPTION disagree:', (app.Product!=app.PRODUCT_DESCRIPTION).sum())"),
]
NB["03_data_integration"] = [
 ("md", "# 03 Data integration\nReceipt Payment is one-to-many on APPLICATION_NUMBER. It is aggregated to application grain before joining so the observation grain stays one row per application."),
 ("code", SETUP),
 ("code", "naive = app.merge(rcpt, on='APPLICATION_NUMBER', how='left')\nfull = data_integration.build_application_dataset(app, rcpt)\nprint('applications:', len(app), '| naive join rows:', len(naive), '| aggregated join rows:', len(full))\nprint('orphan receipts:', (~rcpt.APPLICATION_NUMBER.isin(app.APPLICATION_NUMBER)).sum())"),
 ("code", "print(rcpt.groupby('APPLICATION_NUMBER').size().describe())\nfull[['APPLICATION_NUMBER','receipt_count','receipt_amount_sum','bounced_count','max_dpd_at_receipt']].head()"),
 ("md", "Receipt aggregates are post-disbursal information and are not used as model inputs."),
]
NB["04_eda"] = [
 ("md", "# 04 Exploratory data analysis\nTarget: `Process_from_BRE` (Y = PASS, N = NOT PASS, user-provided definition)."),
 ("code", SETUP),
 ("code", "from IPython.display import Image, display\nfrom src import eda_plots\npaths = eda_plots.make_all(app, y, S.ROOT/'reports'/'figures')\nprint('PASS share:', y.mean().round(4))\nfor p in paths: display(Image(str(p)))"),
 ("code", "sc = ss.association_screen(app, y)\nprint('tests:', sc.p_value.notna().sum(), '| significant (Bonferroni):', int(sc['Significant (Bonferroni, 5%)'].sum()))\nsc.head(22)[['Column','Test','Effect','p_value','p_bonferroni']].round(4)"),
 ("md", "Only the 18 workflow stage-time columns are associated with the target. No application, customer, product, branch, channel or collateral field is."),
]
NB["05_feature_engineering"] = [
 ("md", "# 05 Feature engineering and leakage review\nEvery application-sheet column is either a feature or excluded with a reason."),
 ("code", SETUP),
 ("code", "lk = fe.leakage_report(app)\nprint(lk.Decision.value_counts())\nlk[lk.Decision=='USED AS FEATURE']"),
 ("code", "pd.set_option('display.max_colwidth', 120); lk[lk.Decision=='EXCLUDED'].reset_index(drop=True)"),
 ("code", "X = fe.engineer(app); num_cols, cat_cols = fe.model_columns(); X = X[num_cols+cat_cols]\nprint(X.shape); X.head()"),
 ("md", "## Leakage demonstrations (NOT used in the model)\nThe target equals application-number parity, and the TAT stage columns almost perfectly separate it. A model built on either would look excellent and be meaningless."),
 ("code", "print(ss.sequence_checks(app, y))\nprint('CV AUC from TAT stages only:', round(ss.tat_leakage_demo(app, y), 4))"),
]
NB["06_model_training"] = [
 ("md", "# 06 Model training\nTime-aware split: train Apr-Jun, validate Jul-Aug, test Sep. Logistic Regression, Decision Tree, Random Forest, Gradient Boosting (class_weight balanced where supported)."),
 ("code", SETUP),
 ("code", "from src import model_training as mt, model_evaluation as me\nX = fe.engineer(app); num_cols, cat_cols = fe.model_columns(); X = X[num_cols+cat_cols]\ntr, va, te = mt.time_split(app)\nprint(tr.sum(), va.sum(), te.sum(), '| PASS share', y[tr].mean().round(3), y[va].mean().round(3), y[te].mean().round(3))\nmodels = mt.fit_all(mt.build_models(num_cols, cat_cols), X, y, tr)"),
 ("code", "rows=[]\nfor n,p in models.items():\n    for s,m in [('Train',tr),('Validation',va),('Test',te)]:\n        rows.append({'Model':n,'Split':s, **{k:round(v,4) for k,v in me.metrics(y[m], p.predict_proba(X[m])[:,1]).items() if k in ['Accuracy','F1 (PASS)','ROC-AUC','PR-AUC']}})\npd.DataFrame(rows)"),
]
NB["07_model_evaluation"] = [
 ("md", "# 07 Model evaluation and explainability"),
 ("code", SETUP),
 ("code", "perf = pd.read_csv(S.ROOT/'reports'/'model_performance.csv')\nperf[perf.Split=='Test'][['Model','Accuracy','Precision (PASS)','Recall (PASS)','Recall (NOT PASS)','F1 (PASS)','ROC-AUC','PR-AUC','FP (false PASS)','FN (false NOT PASS)']]"),
 ("code", "pd.read_csv(S.ROOT/'reports'/'rolling_validation_summary.csv')"),
 ("code", "pd.read_csv(S.ROOT/'reports'/'target_validation.csv')"),
 ("code", "pd.read_csv(S.ROOT/'reports'/'feature_importance.csv').head(10)"),
 ("md", "False PASS (model says PASS, BRE says NOT PASS) would let through cases the engine rejects; false NOT PASS would send eligible cases to rejection or manual review. Here both occur at about 50% because the model has no signal. SHAP values are tiny and describe association with the model output, not causation."),
]

nbdir = ROOT / "notebooks"; nbdir.mkdir(exist_ok=True)
for name, cells in NB.items():
    nb = nbf.v4.new_notebook()
    nb.cells = [nbf.v4.new_markdown_cell(src) if kind == "md" else nbf.v4.new_code_cell(src) for kind, src in cells]
    nb.metadata["kernelspec"] = {"name": "python3", "display_name": "Python 3", "language": "python"}
    NotebookClient(nb, timeout=900, kernel_name="python3", resources={"metadata": {"path": str(nbdir)}}).execute()
    nbf.write(nb, nbdir / f"{name}.ipynb")
    print("executed", name)
